package controllers;

import models.Reclamation;
import enums.ReclamationType;
import enums.ReclamationStatus;
import enums.ReclamationPriority;
import services.ReclamationService;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ReclamationController {

}