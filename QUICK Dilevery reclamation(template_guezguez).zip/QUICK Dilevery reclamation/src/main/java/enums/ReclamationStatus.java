package enums;

public enum ReclamationStatus {
    NEW, RECEIVED, IN_PROGRESS, PENDING_RESPONSE, RESOLVED, REJECTED, CLOSED
}
