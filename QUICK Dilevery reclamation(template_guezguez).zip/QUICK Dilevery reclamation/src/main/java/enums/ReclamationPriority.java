package enums;

public enum ReclamationPriority {
    VERY_LOW, LOW, MEDIUM, HIGH, VERY_HIGH
}
