package enums;

public enum ReclamationType {
    ADMIN, MANAGER, CLIENT
}
