module com.example.quick_dilevery {
    requires java.sql;
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;

    // Open packages to JavaFX for reflection (used by FXML and TableView bindings)
    opens controllers to javafx.fxml;
    opens enums to javafx.fxml;
    opens models to javafx.base;
    opens main to javafx.graphics;

    // Export your packages so they can be accessed where needed
    exports controllers;
    exports enums;
    exports models;
    exports main;
}
