package services;

import models.Reclamation;
import enums.ReclamationType;
import enums.ReclamationStatus;
import enums.ReclamationPriority;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReclamationService {

    private Connection connection;

    public ReclamationService() {
        try {
            // Use the MariaDB JDBC URL and ensure the driver is compatible
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/quick_dilevery", "root", "root");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insert(Reclamation r) {
        String query = "INSERT INTO reclamation (id_utilisateur, type, status, description, date_creation, date_update, response, priority) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, r.getId_utilisateur());
            stmt.setString(2, r.getType().name());
            stmt.setString(3, r.getStatus().name());
            stmt.setString(4, r.getDescription());
            stmt.setString(5, r.getDate_creation());
            stmt.setString(6, r.getDate_update());
            stmt.setString(7, r.getResponse());
            stmt.setString(8, r.getPriority().name());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Reclamation> getAll() {
        List<Reclamation> reclamations = new ArrayList<>();
        String query = "SELECT * FROM reclamation";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Reclamation r = new Reclamation(
                        rs.getInt("id_reclamation"),
                        rs.getInt("id_utilisateur"),
                        ReclamationType.valueOf(rs.getString("type")),
                        ReclamationStatus.valueOf(rs.getString("status")),
                        rs.getString("description"),
                        rs.getString("date_creation"),
                        rs.getString("date_update"),
                        rs.getString("response"),
                        ReclamationPriority.valueOf(rs.getString("priority"))
                );
                reclamations.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reclamations;
    }

    public void update(Reclamation r) {
        String query = "UPDATE reclamation SET id_utilisateur = ?, type = ?, status = ?, description = ?, date_update = ?, response = ?, priority = ? WHERE id_reclamation = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, r.getId_utilisateur());
            stmt.setString(2, r.getType().name());
            stmt.setString(3, r.getStatus().name());
            stmt.setString(4, r.getDescription());
            stmt.setString(5, r.getDate_update());
            stmt.setString(6, r.getResponse());
            stmt.setString(7, r.getPriority().name());
            stmt.setInt(8, r.getId_reclamation());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(int id_reclamation) {
        String query = "DELETE FROM reclamation WHERE id_reclamation = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id_reclamation);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
