package controllers;

import enums.ReclamationPriority;
import enums.ReclamationStatus;
import enums.ReclamationType;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import models.Reclamation;
import services.ReclamationService;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ReclamationFormController {

    @FXML private TextField utilisateurField;
    @FXML private ComboBox<ReclamationType> typeComboBox;  // Corrected field name
    @FXML private TextArea descriptionField;
    @FXML private ComboBox<ReclamationPriority> priorityComboBox;  // Corrected field name

    private final ReclamationService reclamationService = new ReclamationService();

    @FXML
    public void initialize() {
        typeComboBox.getItems().addAll(ReclamationType.values());
        priorityComboBox.getItems().addAll(ReclamationPriority.values());
    }

    @FXML
    private void handleModifyReclamation() {
        System.out.println("Modify button clicked");
    }

    @FXML
    private void handleCleareclamation() {
        utilisateurField.clear();
        typeComboBox.setValue(null);
        priorityComboBox.setValue(null);
        descriptionField.clear();
        System.out.println("Clear button clicked");
    }

    @FXML
    private void handleAddReclamation() {
        try {
            int userId = Integer.parseInt(utilisateurField.getText());
            ReclamationType type = typeComboBox.getValue();
            ReclamationPriority priority = priorityComboBox.getValue();
            String description = descriptionField.getText();

            String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            Reclamation reclamation = new Reclamation(
                    0,
                    userId,
                    type,
                    ReclamationStatus.NEW,
                    description,
                    now,
                    now,
                    "No response yet",
                    priority
            );

            reclamationService.insert(reclamation);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setHeaderText(null);
            alert.setContentText("Réclamation ajoutée avec succès !");
            alert.showAndWait();

            clearForm();

        } catch (NumberFormatException e) {
            showError("L'identifiant utilisateur doit être un nombre.");
        } catch (Exception e) {
            e.printStackTrace();
            showError("Erreur lors de l'ajout de la réclamation.");
        }
    }

    private void clearForm() {
        utilisateurField.clear();
        descriptionField.clear();
        typeComboBox.setValue(null);
        priorityComboBox.setValue(null);
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
