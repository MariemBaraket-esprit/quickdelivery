package controllers;

import models.Reclamation;
import enums.ReclamationType;
import enums.ReclamationStatus;
import enums.ReclamationPriority;
import services.ReclamationService;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ReclamationController {

    @FXML private TextField userIdField;
    @FXML private ComboBox<ReclamationType> typeCombo;
    @FXML private ComboBox<ReclamationPriority> priorityCombo;
    @FXML private TextField descriptionField;  // Use TextField here

    @FXML private TableView<Reclamation> tableReclamation;
    @FXML private TableColumn<Reclamation, Integer> colId;
    @FXML private TableColumn<Reclamation, Integer> colUserId;
    @FXML private TableColumn<Reclamation, String> colType;
    @FXML private TableColumn<Reclamation, String> colDescription;
    @FXML private TableColumn<Reclamation, String> colDateCreation;
    @FXML private TableColumn<Reclamation, String> colResponse;
    @FXML private TableColumn<Reclamation, String> colPriority;

    private final ReclamationService reclamationService = new ReclamationService();
    private Reclamation selectedReclamation = null;

    @FXML
    public void initialize() {
        // Set up ComboBoxes with enum values
        typeCombo.setItems(FXCollections.observableArrayList(ReclamationType.values()));
        priorityCombo.setItems(FXCollections.observableArrayList(ReclamationPriority.values()));
        priorityCombo.setValue(ReclamationPriority.MEDIUM);

        // Set up TableView columns
        colId.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getId_reclamation()).asObject());
        colUserId.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getId_utilisateur()).asObject());
        colType.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getType().toString()));
        colDescription.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDescription()));
        colDateCreation.setCellValueFactory(cellData -> new SimpleStringProperty(formatDate(cellData.getValue().getDate_creation())));
        colResponse.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getResponse()));
        colPriority.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getPriority().toString()));

        // Set up listener for TableView row selection
        tableReclamation.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                selectedReclamation = newSelection;
                fillFormWithSelected(newSelection);
            }
        });

        loadTableData();
    }

    private void fillFormWithSelected(Reclamation r) {
        userIdField.setText(String.valueOf(r.getId_utilisateur()));
        typeCombo.setValue(r.getType());
        priorityCombo.setValue(r.getPriority());
        descriptionField.setText(r.getDescription());  // Set the text in descriptionField (TextField)
    }

    @FXML
    private void handleHomeClick() {
        System.out.println("Home clicked");
    }

    @FXML
    private void handleHamburgerClick() {
        System.out.println("Hamburger clicked!");
        // Add logic here to open sidebar/menu/etc.
    }

    @FXML
    private void handleProfileClick() {
        System.out.println("Profile clicked!");
        // Add logic here to open sidebar/menu/etc.
    }

    @FXML
    private void handleAddClick() {
        System.out.println("Add clicked");
    }

    @FXML
    private void handleEditClick() {
        System.out.println("Edit clicked");
    }

    @FXML
    private void handleDiscussionClick() {
        System.out.println("Discussion clicked");
    }

    @FXML
    private void handleNotificationsClick() {
        System.out.println("Notifications clicked");
    }

    @FXML
    public void handleAddReclamation() {
        try {
            int userId = Integer.parseInt(userIdField.getText());
            ReclamationType type = typeCombo.getValue();
            ReclamationPriority priority = priorityCombo.getValue();
            String description = descriptionField.getText();  // Use descriptionField (TextField)

            if (type == null || priority == null || description.isEmpty()) {
                showAlert("Tous les champs sont requis.");
                return;
            }

            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            Reclamation reclamation = new Reclamation(
                    userId,
                    type,
                    ReclamationStatus.NEW,
                    description,
                    timestamp,
                    timestamp,
                    "No response yet",
                    priority
            );

            reclamationService.insert(reclamation);
            clearForm();
            loadTableData();

        } catch (NumberFormatException e) {
            showAlert("L'ID utilisateur doit être un nombre valide.");
        }
    }

    @FXML
    public void handleModifyReclamation() {
        if (selectedReclamation == null) {
            showAlert("Veuillez sélectionner une réclamation à modifier.");
            return;
        }

        try {
            int userId = Integer.parseInt(userIdField.getText());
            ReclamationType type = typeCombo.getValue();
            ReclamationPriority priority = priorityCombo.getValue();
            String description = descriptionField.getText();  // Use descriptionField (TextField)

            if (type == null || priority == null || description.isEmpty()) {
                showAlert("Tous les champs sont requis.");
                return;
            }

            selectedReclamation.setId_utilisateur(userId);
            selectedReclamation.setType(type);
            selectedReclamation.setPriority(priority);
            selectedReclamation.setDescription(description);
            selectedReclamation.setDate_update(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

            reclamationService.update(selectedReclamation);
            clearForm();
            loadTableData();
            selectedReclamation = null;

        } catch (NumberFormatException e) {
            showAlert("L'ID utilisateur doit être un nombre valide.");
        }
    }

    @FXML
    public void handleDeleteReclamation() {
        if (selectedReclamation == null) {
            showAlert("Veuillez sélectionner une réclamation à supprimer.");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirmation de suppression");
        confirmation.setHeaderText(null);
        confirmation.setContentText("Voulez-vous vraiment supprimer cette réclamation ?");

        confirmation.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                reclamationService.delete(selectedReclamation.getId_reclamation());
                loadTableData();
                clearForm();
            }
        });
    }

    private void clearForm() {
        userIdField.clear();
        descriptionField.clear();  // Clear descriptionField (TextField)
        typeCombo.getSelectionModel().clearSelection();
        priorityCombo.setValue(ReclamationPriority.MEDIUM);
        tableReclamation.getSelectionModel().clearSelection();
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Erreur de saisie");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void loadTableData() {
        List<Reclamation> reclamations = reclamationService.getAll();
        tableReclamation.setItems(FXCollections.observableArrayList(reclamations));
    }

    private String formatDate(String date) {
        try {
            LocalDateTime localDateTime = LocalDateTime.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            return localDateTime.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        } catch (Exception e) {
            return date;
        }
    }
}
