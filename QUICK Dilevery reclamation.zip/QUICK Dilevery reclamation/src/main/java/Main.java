package main;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        // Load the FXML file from the correct location
        BorderPane root = FXMLLoader.load(getClass().getResource("/ReclamationView.fxml"));

        // Create the scene with the loaded layout
        Scene scene = new Scene(root, 1400, 700);

        // Load the CSS from the correct path
        scene.getStylesheets().add(getClass().getResource("/styles(CSS)/style.css").toExternalForm());

        // Set up the stage
        primaryStage.setTitle("Reclamation Application");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
