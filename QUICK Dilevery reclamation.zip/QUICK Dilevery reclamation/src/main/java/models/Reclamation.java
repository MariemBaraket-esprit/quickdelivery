package models;

import enums.ReclamationType;
import enums.ReclamationStatus;
import enums.ReclamationPriority;
import javafx.beans.property.*;

public class Reclamation {

    private final IntegerProperty id_reclamation;
    private final IntegerProperty id_utilisateur;
    private final ObjectProperty<ReclamationType> type;
    private final ObjectProperty<ReclamationStatus> status;
    private final StringProperty description;
    private final StringProperty date_creation;
    private final StringProperty date_update;
    private final StringProperty response;
    private final ObjectProperty<ReclamationPriority> priority;

    // Constructor for new Reclamation (ID auto-generated)
    public Reclamation(int id_utilisateur, ReclamationType type, ReclamationStatus status, String description,
                       String date_creation, String date_update, String response, ReclamationPriority priority) {
        this.id_reclamation = new SimpleIntegerProperty(); // Empty for now, can be set later
        this.id_utilisateur = new SimpleIntegerProperty(id_utilisateur);
        this.type = new SimpleObjectProperty<>(type);
        this.status = new SimpleObjectProperty<>(status);
        this.description = new SimpleStringProperty(description);
        this.date_creation = new SimpleStringProperty(date_creation);
        this.date_update = new SimpleStringProperty(date_update);
        this.response = new SimpleStringProperty(response);
        this.priority = new SimpleObjectProperty<>(priority);
    }

    // Constructor for Reclamation with ID (loaded from DB)
    public Reclamation(int id_reclamation, int id_utilisateur, ReclamationType type, ReclamationStatus status,
                       String description, String date_creation, String date_update, String response, ReclamationPriority priority) {
        this.id_reclamation = new SimpleIntegerProperty(id_reclamation);
        this.id_utilisateur = new SimpleIntegerProperty(id_utilisateur);
        this.type = new SimpleObjectProperty<>(type);
        this.status = new SimpleObjectProperty<>(status);
        this.description = new SimpleStringProperty(description);
        this.date_creation = new SimpleStringProperty(date_creation);
        this.date_update = new SimpleStringProperty(date_update);
        this.response = new SimpleStringProperty(response);
        this.priority = new SimpleObjectProperty<>(priority);
    }

    // Getters
    public int getId_reclamation() {
        return id_reclamation.get();
    }

    public IntegerProperty id_reclamationProperty() {
        return id_reclamation;
    }

    public int getId_utilisateur() {
        return id_utilisateur.get();
    }

    public IntegerProperty id_utilisateurProperty() {
        return id_utilisateur;
    }

    public ReclamationType getType() {
        return type.get();
    }

    public ObjectProperty<ReclamationType> typeProperty() {
        return type;
    }

    public ReclamationStatus getStatus() {
        return status.get();
    }

    public ObjectProperty<ReclamationStatus> statusProperty() {
        return status;
    }

    public String getDescription() {
        return description.get();
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public String getDate_creation() {
        return date_creation.get();
    }

    public StringProperty date_creationProperty() {
        return date_creation;
    }

    public String getDate_update() {
        return date_update.get();
    }

    public StringProperty date_updateProperty() {
        return date_update;
    }

    public String getResponse() {
        return response.get();
    }

    public StringProperty responseProperty() {
        return response;
    }

    public ReclamationPriority getPriority() {
        return priority.get();
    }

    public ObjectProperty<ReclamationPriority> priorityProperty() {
        return priority;
    }

    // Setters
    public void setId_reclamation(int id_reclamation) {
        this.id_reclamation.set(id_reclamation);
    }

    public void setId_utilisateur(int id_utilisateur) {
        this.id_utilisateur.set(id_utilisateur);
    }

    public void setType(ReclamationType type) {
        this.type.set(type);
    }

    public void setStatus(ReclamationStatus status) {
        this.status.set(status);
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public void setDate_creation(String date_creation) {
        this.date_creation.set(date_creation);
    }

    public void setDate_update(String date_update) {
        this.date_update.set(date_update);
    }

    public void setResponse(String response) {
        this.response.set(response);
    }

    public void setPriority(ReclamationPriority priority) {
        this.priority.set(priority);
    }
}
